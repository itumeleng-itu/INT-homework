/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.entity;

import java.util.List;
import javax.annotation.security.RolesAllowed;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

/**
 *
 * @author matom
 */
@Stateless
public class StudentCardFacade extends AbstractFacade<StudentCard> implements StudentCardFacadeLocal {

    @PersistenceContext(unitName = "GenerateStudCardEJBModulePU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public StudentCardFacade() {
        super(StudentCard.class);
    }

    @RolesAllowed("lecturer")
    @Override
    public List<StudentCard> findWithCode(String coursecode) {
        Query query = em.createQuery("select sc from StudentCard where sc.coursecode= ?1");
        query.setParameter(1, coursecode);
        List<StudentCard> studcard = query.getResultList();
        return studcard;
    }
    
}
